// fibonacci series from 1- 100

   function fibonacci(num){
       let n1 = 0;
       let n2 = 1;
       let n3;
       console.log(n1);
       console.log(n2);
       for(let i = 0; i < num; i++){
           n3 = n1 + n2;
           n1 = n2;
           n2 = n3;
           console.log(n3);
       }
       
   }

fibonacci(10);

// checking the input whether string or not


// let string = document.getElementById('text_2').value;
// let btn = document.getElementById('btn');
// //let charCode = string.charCodeAt(0);
// btn.addEventListener('keyPress', function(event){
//    // console.log(charCode);
    
//   //  if(charCode > 65 || charCode < 90){
//     //var letters = /^[a-zA-Z]+$/;
//     var x = event.which || event.keyCode;
//     console.log(x);
//     // if( {
//     //     console.log("the input is string");
//     //     return true;
//     // }else{
//     // console.log("the input is not string");
//     // return false;
//     // }
// })

// function check(event){
//     x = event.keycode;
//     console.log(x)
// }

// function myFunction(event) {

//     // x = event.which || event.keyCode;
//     // console.log(event);
//     let x = event.keycode;
//     if(x > 65 || x < 90){

//         document.getElementById("demo").innerHTML = "The Unicode value is: " + event.keycode;
//     } else{
//         document.getElementById("demo").innerHTML = "something";
//     }
//   }

//to check the input string or not

let input = "text";

if(typeof input ==="string"){
    console.log("it is string");
}else{
    console.log("it is not string");
}


// count the number of characters

let str = "achieversit";

let count_str = str.length;

console.log(count_str);


// to print properties of object

let _obj = {
    firstName : 'Mr',
    lastName : 'sharma',
    
    phoneNumber : 9999999999,
    Address : '276-6 2nd Phase BTM-layout'
    }

    console.log(_obj.firstName, _obj.phoneNumber);



    // sorting Array

    let myArray = [2, 24, 54, 22, 19, 26];

    console.log(myArray.sort((a,b) => {
          return a-b;
        }));
    

   