// Task- Array in reverse order

let arr1 =  [23,45,67,78,89,90];

let sortedArr = [];

for(let i = 0; i = arr1.length; i++){
    sortedArr.push(arr1.pop());
    
}
console.log(sortedArr);




//Task 2 finding the max value

let arr2 =  [23,45,12,34,455,66,45,21,127];

let maxVal = Math.max(...arr2);

console.log(maxVal + ' is maximum');





//Task 3 finding 2 numbers in an array which equals to 10

let arr3 = [2,3,5, 7,9,0];

const sum = (arr, target) => {
for(let i = 0; i < arr.length; i++){
for(let j = i + 1; j < arr.length; j++){
    if(arr[i] + arr[j] === target){
        console.log(arr[i] , arr[j]);
    }
}
}
}

sum(arr3, 10);






// Task 4 finding the peak value

let arr4 = [12,32,44,55,11,33,56];

for(let i = 0; i < arr4.length; i++){
    if(arr4[i-1] < arr4[i] && arr4[i] > arr4[i+1]){
        console.log(arr4[i] + " is the peak value");
    }
}






// Task 5 finding an item which has no character 'a' in an array

let arr5 =  ['apple','orange','fruit','banana'];

    for(let i = 0; i < arr5.length; i++){
        let splitArr = arr5[i].split('');
        if(splitArr.indexOf('a') === -1)
                console.log(arr5[i]);           
        
    }